---
title: Examples
template: page.ejs
---

Examples
========

* [Basic Todos](/guides/quick-start.html) is a *very* simple todo app; build this app yourself with step-by-step instructions in the [quick-start guide](/guides/quick-start.html).
* [Image Carousel](/examples/carousel/) is a simple image carousel that uses two stores.
* [Asynchronous Data](/guides/async-data.html) demonstrates how to deal with asynchronous data loading in a flux application.
* [React Router](/examples/react-router.html) demonstrates how to integrate Fluxxor with react-router, a React-based routing solution.
