---
title: Installation
template: page.ejs
---

Installation
============

<meta http-equiv="refresh" content="0; url=/guides/installation.html">

[This content has moved. Click here if you are not automatically redirected.](/guides/installation.html)
